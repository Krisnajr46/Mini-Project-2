import json
import os
import time

import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point, WritePrecision

MQTT_BROKER = os.getenv("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "energy/telemetry")
INFLUX_URL = os.getenv("INFLUX_URL", "http://influxdb:8086")
INFLUX_TOKEN = os.getenv("INFLUX_TOKEN")
INFLUX_ORG = os.getenv("INFLUX_ORG", "iot-org")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "energy")

db = None
write_api = None

while True:
    try:
        db = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
        if db.health().status == "pass":
            write_api = db.write_api()
            break
    except Exception as exc:
        print(f"Waiting for InfluxDB: {exc}")
    time.sleep(3)

def on_connect(client, userdata, flags, reason_code, properties):
    print(f"Connected to MQTT: {reason_code}")
    client.subscribe(MQTT_TOPIC, qos=1)
    print(f"Subscribed to {MQTT_TOPIC}")

def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode())
        required = ["device_id", "voltage", "current", "power", "energy",
                    "power_factor", "frequency"]
        if any(key not in data for key in required):
            print("Invalid telemetry: missing field")
            return

        point = (
            Point("energy_telemetry")
            .tag("device_id", str(data["device_id"]))
            .field("voltage", float(data["voltage"]))
            .field("current", float(data["current"]))
            .field("power", float(data["power"]))
            .field("energy", float(data["energy"]))
            .field("power_factor", float(data["power_factor"]))
            .field("frequency", float(data["frequency"]))
            .time(data.get("timestamp"), WritePrecision.NS)
        )
        write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=point)
        print(f"Stored telemetry: {data['device_id']} power={data['power']}W")
    except Exception as exc:
        print(f"Processing error: {exc}")

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_message = on_message

while True:
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        client.loop_forever()
    except Exception as exc:
        print(f"MQTT connection error: {exc}")
        time.sleep(3)
