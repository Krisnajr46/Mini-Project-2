# IoT Energy Monitoring Pipeline

Mini project based on the provided assignment architecture:
Simulated Energy Meter -> MQTT -> Ingestion Service -> Time-Series Database -> Dashboard.

## Run on EC2

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
```

Log out/in after adding the user to docker, then:

```bash
cd iot-energy-monitoring
docker compose up -d --build
docker compose ps
docker compose logs -f simulator ingestion
```

## Access

- Grafana: `http://EC2_PUBLIC_IP:3000`
  - user: `admin`
  - password: `admin123`
- InfluxDB: `http://EC2_PUBLIC_IP:8086`
  - user: `admin`
  - password: `iotpassword123`

For AWS Security Group, expose TCP 3000 and 8086 only when needed for the demo. MQTT 1883 does not need to be publicly exposed because the simulator, broker and ingestion service communicate inside the Docker network.

## Verify data

```bash
docker compose logs --tail=50 simulator
docker compose logs --tail=50 ingestion
```

The simulator sends device telemetry every 5 seconds. The ingestion service validates the required fields and stores measurements in InfluxDB.
