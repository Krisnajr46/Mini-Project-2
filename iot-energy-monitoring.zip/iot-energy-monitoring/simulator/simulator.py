import json
import math
import os
import random
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

BROKER = os.getenv("MQTT_BROKER", "localhost")
PORT = int(os.getenv("MQTT_PORT", "1883"))
TOPIC = os.getenv("MQTT_TOPIC", "energy/telemetry")
DEVICE_COUNT = int(os.getenv("DEVICE_COUNT", "3"))
INTERVAL = float(os.getenv("INTERVAL_SECONDS", "5"))

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

while True:
    try:
        client.connect(BROKER, PORT, 60)
        break
    except Exception as exc:
        print(f"Waiting for MQTT broker: {exc}")
        time.sleep(3)

client.loop_start()
print(f"Publishing telemetry to {TOPIC}")

t = 0
while True:
    for i in range(1, DEVICE_COUNT + 1):
        device_id = f"meter-{i:03d}"
        voltage = round(220 + random.uniform(-3, 3), 2)
        current = round(2.0 + 1.5 * (1 + math.sin(t / 8 + i)) + random.uniform(-0.3, 0.3), 2)
        power_factor = round(random.uniform(0.90, 0.99), 2)
        power = round(voltage * current * power_factor, 2)
        energy = round(power * INTERVAL / 3600000, 6)
        frequency = round(50 + random.uniform(-0.05, 0.05), 2)

        payload = {
            "device_id": device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "voltage": voltage,
            "current": current,
            "power": power,
            "energy": energy,
            "power_factor": power_factor,
            "frequency": frequency,
        }

        result = client.publish(TOPIC, json.dumps(payload), qos=1)
        print(f"Published: {payload} | rc={result.rc}")

    t += 1
    time.sleep(INTERVAL)
